package com.sheeds.controller;

import com.sheeds.dao.UserDAO;
import com.sheeds.model.Review;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ReviewServlet")
public class ReviewServlet extends HttpServlet {
    
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check if an admin is trying to view the reviews page via a direct link
        String view = request.getParameter("view");
        if ("admin".equals(view)) {
            List<Review> reviews = userDAO.getAllReviews();
            request.setAttribute("reviews", reviews);
            request.getRequestDispatcher("admin_reviews.jsp").forward(request, response); // Update filename if different
            return;
        }
        
        // Otherwise, load standard user view
        loadReviews(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                String username = (String) request.getSession().getAttribute("user");
                String ratingStr = request.getParameter("rating");
                String comments = request.getParameter("comments");

                int rating = 0;
                if (ratingStr != null && !ratingStr.trim().isEmpty()) {
                    rating = Integer.parseInt(ratingStr.trim());
                }
                
                userDAO.addReview(username, rating, comments);

            } else if ("delete".equals(action)) {
                String reviewIdStr = request.getParameter("reviewId");
                
                if (reviewIdStr != null && !reviewIdStr.trim().isEmpty()) {
                    int reviewId = Integer.parseInt(reviewIdStr);
                    userDAO.deleteReview(reviewId);
                }
                
            } else if ("update".equals(action)) {
                // Catches the submission from edit_review.jsp
                String reviewIdStr = request.getParameter("reviewId");
                String ratingStr = request.getParameter("rating");
                String comments = request.getParameter("comments");
                
                if (reviewIdStr != null && ratingStr != null) {
                    int reviewId = Integer.parseInt(reviewIdStr.trim());
                    int rating = Integer.parseInt(ratingStr.trim());
                    
                    userDAO.updateReview(reviewId, rating, comments);
                }
            }
        } catch (Exception e) {
            System.out.println("Error processing review action: " + e.getMessage());
            e.printStackTrace();
        }
        
        // --- ROUTING LOGIC ---
        // Check if the request came from the admin dashboard's delete button
        String source = request.getParameter("source");
        
        if ("admin".equals(source)) {
            List<Review> reviews = userDAO.getAllReviews();
            request.setAttribute("reviews", reviews);
            request.getRequestDispatcher("admin_reviews.jsp").forward(request, response); // Update filename if different
        } else {
            // Standard routing for regular users
            loadReviews(request, response);
        }
    }

    // Helper method to keep code clean
    private void loadReviews(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Review> reviews = userDAO.getAllReviews(); 
        request.setAttribute("reviews", reviews);
        request.getRequestDispatcher("review.jsp").forward(request, response);
    }
}