package com.sheeds.controller;

import com.sheeds.dao.UserDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Grab what the user typed in the form
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // Default role for anyone signing up from the website is "customer"
        String role = "customer"; 

        UserDAO userDAO = new UserDAO();
        
        // 2. Try to register the user in the database
        boolean isRegistered = userDAO.registerUser(username, email, password, role);

        if (isRegistered) {
            // Success! Send them to login page with a nice message
            response.sendRedirect("login.jsp?message=registered");
        } else {
            // Failed (usually because the username is already taken)
            response.sendRedirect("register.jsp?error=username_taken");
        }
    }
}