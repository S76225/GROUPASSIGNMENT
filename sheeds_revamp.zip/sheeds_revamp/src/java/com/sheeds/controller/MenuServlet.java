package com.sheeds.controller;

import com.sheeds.dao.MenuDAO;
import com.sheeds.model.MenuItem;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/MenuServlet")
public class MenuServlet extends HttpServlet {
    
    private MenuDAO menuDAO = new MenuDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Fetch the entire menu from the database
        List<MenuItem> menuList = menuDAO.getAllItems();
        request.setAttribute("menuList", menuList);
        
        // 2. Check if the admin is requesting the page
        String view = request.getParameter("view");
        
        if ("admin".equals(view)) {
            // Forward to the admin menu management page
            request.getRequestDispatcher("admin_menu.jsp").forward(request, response);
        } else {
            // Forward to the standard customer-facing menu page
            request.getRequestDispatcher("menu.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("add".equals(action)) {
                // Grab data from the "+ Add Item" form
                String itemId = request.getParameter("itemId");
                
                // --- THE AUTO-ID GENERATOR ---
                // If the HTML form didn't send an ID, Java creates one automatically!
                if (itemId == null || itemId.trim().isEmpty()) {
                    // Generates a random number between 100 and 999
                    int randomNum = (int)(Math.random() * 900) + 100; 
                    itemId = "M-" + randomNum; // Combines it to make "M-123"
                }
                
                String name = request.getParameter("name");
                String category = request.getParameter("category");
                String priceStr = request.getParameter("price");
                String status = request.getParameter("status");
                
                // Safely parse the price
                double price = 0.0;
                if (priceStr != null && !priceStr.trim().isEmpty()) {
                    price = Double.parseDouble(priceStr.trim());
                }
                
                // --- THE STATUS FIX ---
                // If the form doesn't provide a status, explicitly set it to "Available"
                if (status == null || status.trim().isEmpty()) {
                    status = "Available";
                }
                
                // Create the object and save to DB
                MenuItem newItem = new MenuItem(itemId, name, category, price, status);
                menuDAO.addItem(newItem);
                
            } else if ("delete".equals(action)) {
                // Grab the ID from the trash can button form
                String itemId = request.getParameter("itemId");
                
                if (itemId != null && !itemId.trim().isEmpty()) {
                    menuDAO.deleteItem(itemId);
                }
            }
            
        } catch (Exception e) {
            System.out.println("Error processing menu action: " + e.getMessage());
            e.printStackTrace();
        }
        
        // After an item is added or deleted, instantly reload the admin menu page
        response.sendRedirect("MenuServlet?view=admin");
    }
}