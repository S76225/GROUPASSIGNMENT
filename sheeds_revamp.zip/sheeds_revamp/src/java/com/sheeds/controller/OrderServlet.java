package com.sheeds.controller;

import com.sheeds.dao.MenuDAO;
import com.sheeds.dao.OrderDAO;
import com.sheeds.model.MenuItem;
import com.sheeds.model.Order;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
    
    private MenuDAO menuDAO = new MenuDAO();
    private OrderDAO orderDAO = new OrderDAO(); 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
            
        String view = request.getParameter("view");
        String action = request.getParameter("action");
        
        // --- ACTION BUTTON ROUTING (Mark Ready & Delete) ---
        if (action != null) {
            int orderId = Integer.parseInt(request.getParameter("id"));
            
            if ("markReady".equals(action)) {
                orderDAO.updateOrderStatus(orderId, "Ready");
            } else if ("delete".equals(action)) {
                orderDAO.deleteOrder(orderId);
            }
            
            // Redirect straight back to the Admin Dashboard
            response.sendRedirect("OrderServlet?view=admin");
            return;
        }
        
        // --- ADMIN ROUTING ---
        if ("admin".equals(view)) {
            List<Order> ordersList = orderDAO.getAllOrders();
            request.setAttribute("ordersList", ordersList);
            request.getRequestDispatcher("admin_orders.jsp").forward(request, response);
            return; 
        }
        
        // --- CUSTOMER ROUTING ---
        List<MenuItem> menuList = menuDAO.getAllItems();
        request.setAttribute("menuList", menuList);
        request.getRequestDispatcher("order.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        try {
            if ("placeOrder".equals(action)) {
                
                String customerName = request.getParameter("customerName");
                String itemName = request.getParameter("itemName");
                String orderType = request.getParameter("orderType");
                int quantity = Integer.parseInt(request.getParameter("quantity"));
                
                // --- CALCULATE THE TOTAL PRICE ---
                double price = 0.0;
                List<MenuItem> menu = menuDAO.getAllItems();
                for (MenuItem item : menu) {
                    if (item.getName().equals(itemName)) {
                        price = item.getPrice();
                        break;
                    }
                }
                double totalAmount = price * quantity;
                
                // --- CREATE AND SAVE ORDER ---
                Order newOrder = new Order();
                newOrder.setCustomerName(customerName);
                newOrder.setItemName(itemName);
                newOrder.setQuantity(quantity);
                newOrder.setOrderType(orderType);
                newOrder.setTotalAmount(totalAmount);
                newOrder.setStatus("Pending");
                
                orderDAO.addOrder(newOrder);
                
                response.sendRedirect("OrderServlet?success=true"); 
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("OrderServlet?error=true");
        }
    }
}