package com.sheeds.controller;

import com.sheeds.dao.ReviewDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminReviewServlet")
public class AdminReviewServlet extends HttpServlet {
    private ReviewDAO reviewDAO = new ReviewDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
        // Security Gatekeeper: Kick out anyone who isn't an admin
        if (session == null || !"admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp?error=unauthorized");
            return;
        }

        // Fetch all reviews and send them to the new admin JSP
        request.setAttribute("reviews", reviewDAO.getAllReviews());
        request.getRequestDispatcher("admin_reviews.jsp").forward(request, response);
    }
}