package com.sheeds.controller;

import com.sheeds.dao.UserDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // If someone tries to access the servlet directly via URL, just send them to the login page
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try {
            // Authenticate and get the role back from the database
            String role = userDAO.authenticateUser(username, password);
            
            if (role != null) {
                // Login Successful! Create the session
                HttpSession session = request.getSession();
                session.setAttribute("user", username);
                session.setAttribute("role", role); // Save the role so the whole site knows who they are
                
                // --- ROLE-BASED ROUTING ---
                if ("admin".equals(role)) {
                    // Send admins to the admin dashboard
                    // Make sure "admin_menu.jsp" matches the actual name of your main admin page!
                    response.sendRedirect("MenuServlet?view=admin"); 
                } else {
                    // Send regular users to the home page
                    response.sendRedirect("index.jsp"); 
                }
                
            } else {
                // Login Failed - Wrong username or password
                request.setAttribute("errorMessage", "Invalid username or password.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            System.out.println("Error during login: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred. Please try again.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}