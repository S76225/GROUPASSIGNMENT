package com.sheeds.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Get the current session (if it exists)
        HttpSession session = request.getSession(false);
        
        if (session != null) {
            // 2. Invalidate/Destroy the session entirely
            session.invalidate();
        }
        
        // 3. Redirect back to the HOME PAGE instead of login
        response.sendRedirect("index.jsp?message=logged_out");
    }
}