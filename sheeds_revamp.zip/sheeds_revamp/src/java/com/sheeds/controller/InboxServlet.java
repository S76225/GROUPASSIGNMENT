package com.sheeds.controller;


import com.sheeds.dao.*; // Accesses your new DAO layer
import com.sheeds.model.*; // Accesses your data objects
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/InboxServlet")
public class InboxServlet extends HttpServlet {
    private MessageDAO messageDAO = new MessageDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if ("delete".equals(request.getParameter("action"))) {
            // Note: Add deleteMessage(id) to your MessageDAO similarly to ReviewDAO
        }
        request.setAttribute("messages", messageDAO.getAllMessages());
        request.getRequestDispatcher("admin_inbox.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        messageDAO.addMessage(new Message("MSG-" + System.currentTimeMillis() % 1000, 
                             request.getParameter("name"), request.getParameter("email"), request.getParameter("message")));
        response.sendRedirect("contact.jsp?success=true");
    }
}