package com.sheeds.model;

public class Order {
    
    // 1. Private Fields
    private int orderId;
    private String customerName;
    private String itemName;
    private int quantity;
    private String orderType;
    private double totalAmount;
    private String status;

    // 2. Empty Constructor (Required by Java Server Pages)
    public Order() {
    }

    // 3. The 5-Parameter Constructor (Fixes the "no suitable constructor" build error)
    public Order(int orderId, String customerName, String itemName, int quantity, String orderType) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.itemName = itemName;
        this.quantity = quantity;
        this.orderType = orderType;
        
        // Default values for the new fields so your JSP doesn't crash
        this.totalAmount = 0.0; 
        this.status = "Pending";
    }

    // 4. The 7-Parameter Constructor (For future-proofing or full database queries)
    public Order(int orderId, String customerName, String itemName, int quantity, 
                 String orderType, double totalAmount, String status) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.itemName = itemName;
        this.quantity = quantity;
        this.orderType = orderType;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // 5. Getters and Setters
    
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}