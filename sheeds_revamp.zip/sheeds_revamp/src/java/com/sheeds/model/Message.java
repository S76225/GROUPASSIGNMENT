package com.sheeds.model;

public class Message {
    private String messageId;
    private String name;
    private String email;
    private String content;

    public Message(String messageId, String name, String email, String content) {
        this.messageId = messageId;
        this.name = name;
        this.email = email;
        this.content = content;
    }

    // Getters
    public String getMessageId() { return messageId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getContent() { return content; }
}