package com.sheeds.model;

public class MenuItem {
    private String itemId;
    private String name;
    private String category;
    private double price;
    private String status;

    public MenuItem(String itemId, String name, String category, double price, String status) {
        this.itemId = itemId; this.name = name; this.category = category; this.price = price; this.status = status;
    }
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public String getStatus() { return status; }
}