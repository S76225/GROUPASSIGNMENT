package com.sheeds.model;

public class Review {
    private int reviewId;
    private String customerName;
    private int rating;
    private String comments;
    private String username; // Added this 5th field

    // This constructor now accepts 5 arguments
    public Review(int reviewId, String customerName, int rating, String comments, String username) {
        this.reviewId = reviewId;
        this.customerName = customerName;
        this.rating = rating;
        this.comments = comments;
        this.username = username;
    }

    // Add getters for all fields
    public int getReviewId() { return reviewId; }
    public String getCustomerName() { return customerName; }
    public int getRating() { return rating; }
    public String getComments() { return comments; }
    public String getUsername() { return username; }
}