package com.sheeds.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Replace 'root' and '' with your MySQL username and password
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/sheeds_db", "root", "");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}