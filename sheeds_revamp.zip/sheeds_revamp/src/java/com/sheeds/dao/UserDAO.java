package com.sheeds.dao;

import com.sheeds.util.DBConnection; 
import com.sheeds.model.Review;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // Database Credentials - Adjust if necessary
    private String jdbcURL = "jdbc:mysql://localhost:3306/sheeds_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    // Database Connection Helper
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sheeds_db", "root", "");
        } catch (Exception e) {
            e.printStackTrace(); // This is the crucial part!
        }
        return connection;
    }

    // --- AUTHENTICATION METHODS ---
    public boolean registerUser(String username, String email, String password, String role) {
        String sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            statement.setString(2, email);
            statement.setString(3, password);
            statement.setString(4, role);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // In UserDAO.java
    public String authenticateUser(String username, String password) {
        String sql = "SELECT role FROM users WHERE username = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getString("role"); // Returns "admin" or "user"
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Returns null if login fails
    }

    // --- REVIEW METHODS ---

    public void addReview(String username, int rating, String comments) {
        // Updated to include 'customer_name' to prevent 'NULL' constraint errors
        String sql = "INSERT INTO reviews (username, rating, comments, customer_name) VALUES (?, ?, ?, ?)";
        
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, username);
            ps.setInt(2, rating);
            ps.setString(3, comments);
            ps.setString(4, username); // Saving username as customer_name
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace(); // Check NetBeans output for errors if this fails
        }
    }
    
    public void deleteReview(int reviewId) {
        String sql = "DELETE FROM reviews WHERE review_id = ?";
        
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, reviewId);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void updateReview(int reviewId, int rating, String comments) {
        String sql = "UPDATE reviews SET rating = ?, comments = ? WHERE review_id = ?";
        
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, rating);
            ps.setString(2, comments);
            ps.setInt(3, reviewId);
            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Review> getAllReviews() {
        List<Review> reviews = new ArrayList<>();
        // Using exact column names from your database screenshot
        String sql = "SELECT review_id, customer_name, rating, comments, username FROM reviews ORDER BY review_id DESC";
        
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                // Mapping exactly to your database columns
                Review review = new Review(
                    rs.getInt("review_id"),
                    rs.getString("customer_name"),
                    rs.getInt("rating"),
                    rs.getString("comments"),
                    rs.getString("username")
                );
                reviews.add(review);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reviews;
    }
}