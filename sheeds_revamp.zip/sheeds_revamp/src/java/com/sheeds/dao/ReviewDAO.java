package com.sheeds.dao;

import com.sheeds.model.Review;
import com.sheeds.util.DBConnection;
import java.sql.*;
import java.util.*;

public class ReviewDAO {

    public List<Review> getAllReviews() {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM reviews";
        try (Connection con = DBConnection.getConnection(); ResultSet rs = con.createStatement().executeQuery(sql)) {
            while (rs.next()) {
                // Replace your current list.add line with this one:
                list.add(new Review(
                        rs.getInt("review_id"),
                        rs.getString("customer_name"),
                        rs.getInt("rating"),
                        rs.getString("comments"),
                        rs.getString("username")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean isReviewOwner(String reviewId, String currentUsername) {
        String sql = "SELECT username FROM reviews WHERE review_id = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reviewId);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getString("username").equals(currentUsername);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void updateReview(String id, int rating, String comments) {
        String sql = "UPDATE reviews SET rating=?, comments=? WHERE review_id=?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, rating);
            ps.setString(2, comments);
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
