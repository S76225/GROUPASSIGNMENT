package com.sheeds.dao;

import com.sheeds.model.Order;
import com.sheeds.util.DBConnection;
import java.sql.*;
import java.util.*;

public class OrderDAO {
    
    // 1. Fetch all orders (Now includes Total Amount and Status)
    public List<Order> getAllOrders() {
        List<Order> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM orders ORDER BY order_id DESC")) {
             
            while (rs.next()) {
                list.add(new Order(
                    rs.getInt("order_id"), 
                    rs.getString("customer_name"), 
                    rs.getString("item_name"), 
                    rs.getInt("quantity"), 
                    rs.getString("order_type"),
                    rs.getDouble("total_amount"), // Added!
                    rs.getString("status")        // Added!
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
    
    // 2. Save a new order
    public void addOrder(Order o) {
        String sql = "INSERT INTO orders (customer_name, item_name, quantity, order_type, total_amount, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
             
            ps.setString(1, o.getCustomerName());
            ps.setString(2, o.getItemName());
            ps.setInt(3, o.getQuantity());
            ps.setString(4, o.getOrderType());
            ps.setDouble(5, o.getTotalAmount()); // Added!
            ps.setString(6, "Pending");          // Force new orders to Pending
            ps.executeUpdate();
            
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 3. Update Status (For the 'Mark Ready' button)
    public void updateOrderStatus(int orderId, String newStatus) {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, orderId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // 4. Delete Order (For the Trash button)
    public void deleteOrder(int orderId) {
        String sql = "DELETE FROM orders WHERE order_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}