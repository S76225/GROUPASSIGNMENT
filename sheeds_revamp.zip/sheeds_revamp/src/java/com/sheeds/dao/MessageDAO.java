package com.sheeds.dao;
import com.sheeds.model.Message;
import com.sheeds.util.DBConnection;
import java.sql.*;
import java.util.*;

public class MessageDAO {
    public List<Message> getAllMessages() {
        List<Message> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             ResultSet rs = con.createStatement().executeQuery("SELECT * FROM messages")) {
            while (rs.next()) {
                list.add(new Message(rs.getString("message_id"), rs.getString("name"), 
                          rs.getString("email"), rs.getString("content")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public void addMessage(Message m) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("INSERT INTO messages VALUES (?, ?, ?, ?)")) {
            ps.setString(1, m.getMessageId());
            ps.setString(2, m.getName());
            ps.setString(3, m.getEmail());
            ps.setString(4, m.getContent());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }
}