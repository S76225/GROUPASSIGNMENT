<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inbox | Admin Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fbf8cc; display: flex; height: 100vh; overflow: hidden; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .message-card { background-color: white; border-radius: 12px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

    <!-- This replaces your previous hardcoded sidebar -->
    <%@ include file="admin_sidebar.jsp" %>

    <div class="main-content">
        <h3 class="mb-4 fw-bold">Customer Messages</h3>
        <div class="row">
            <c:forEach var="msg" items="${messages}">
                <div class="col-md-12 mb-3">
                    <div class="message-card">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <h5 class="fw-bold m-0">${msg.name}</h5>
                                <small class="text-muted"><i class="bi bi-envelope me-1"></i> ${msg.email}</small>
                            </div>
                            <span class="badge bg-light text-dark border">#${msg.messageId}</span>
                        </div>
                        <p class="mt-3 mb-3 text-dark">${msg.content}</p>
                        <div class="d-flex justify-content-end">
                            <a href="mailto:${msg.email}" class="btn btn-sm btn-outline-primary me-2"><i class="bi bi-reply"></i> Reply</a>
                            <a href="InboxServlet?action=delete&id=${msg.messageId}" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Delete</a>
                        </div>
                    </div>
                </div>
            </c:forEach>
            <c:if test="${empty messages}">
                <div class="col-12 text-center text-muted mt-5">
                    <i class="bi bi-inbox fs-1"></i><p>No new messages.</p>
                </div>
            </c:if>
        </div>
    </div>
</body>
</html>