<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<%
    // Get the current URL from the server to determine the active page
    String currentURL = request.getRequestURI();
%>

<style>
    /* Styling for the Active Link */
    .navbar-nav .nav-link.active-link {
        font-weight: 700 !important;         /* Make it bold */
        color: #4a3b32 !important;           /* Deep brown color */
        border-bottom: 3px solid #4a3b32;    /* Add a nice underline */
    }
</style>

<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm py-3">
    <div class="container">
        
        <!-- Logo and Brand -->
        <a class="navbar-brand d-flex align-items-center fw-bold" href="index.jsp" style="color: #4a3b32; font-size: 1.5rem;">
            <img src="images/logo.png" alt="" height="30" class="me-2" onerror="this.style.display='none'">
            Sheed's Cafe
        </a>

        <!-- Mobile Toggle Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            
            <!-- Center Navigation Links with Active State Logic -->
            <ul class="navbar-nav mx-auto fs-5">
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.endsWith("index.jsp") || currentURL.endsWith("/") ? "active-link" : "" %>" href="index.jsp">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.contains("MenuServlet") || currentURL.contains("menu.jsp") ? "active-link" : "" %>" href="MenuServlet">Menu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.contains("story.jsp") ? "active-link" : "" %>" href="story.jsp">Our Story</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.contains("drip.jsp") ? "active-link" : "" %>" href="drip.jsp">The Drip</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.contains("ReviewServlet") || currentURL.contains("review.jsp") ? "active-link" : "" %>" href="ReviewServlet">Reviews</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link px-3 <%= currentURL.contains("contact.jsp") ? "active-link" : "" %>" href="contact.jsp">Contact</a>
                </li>
            </ul>

            <!-- Right Side: Auth Logic & Order Button -->
            <div class="d-flex align-items-center gap-3">
                <c:choose>
                    <c:when test="${sessionScope.user != null}">
                        <a href="LogoutServlet" class="text-danger text-decoration-none fw-bold">Logout (${sessionScope.user})</a>
                    </c:when>
                    <c:otherwise>
                        <a href="login.jsp" class="text-muted text-decoration-none">Login</a>
                        <a href="register.jsp" class="text-muted text-decoration-none fw-bold ms-2">Sign Up</a>
                    </c:otherwise>
                </c:choose>

                <a href="OrderServlet" class="btn text-white px-4 py-2 fw-semibold" style="background-color: #4a3b32; border-radius: 6px;">
                    Order Online
                </a>
            </div>
        </div>
    </div>
</nav>