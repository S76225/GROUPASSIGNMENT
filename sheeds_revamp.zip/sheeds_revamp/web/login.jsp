<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
        .auth-card { background-color: white; border-radius: 12px; border: none; }
        .btn-cafe { background-color: #4a3b32; color: white; transition: 0.3s; }
        .btn-cafe:hover { background-color: #2b1f17; color: white; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Master Navigation -->
    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1 d-flex justify-content-center align-items-center">
        <div class="card auth-card shadow-sm p-4" style="max-width: 400px; width: 100%;">
            <div class="text-center mb-4">
                <h3 class="fw-bold" style="color: #3a2b1c;">Welcome Back</h3>
                <p class="text-muted">Please log in to your account.</p>
            </div>

            <!-- Message Handlers -->
            <% if ("invalid_credentials".equals(request.getParameter("error"))) { %>
                <div class="alert alert-danger py-2 text-center">Invalid username or password.</div>
            <% } else if ("unauthorized".equals(request.getParameter("error"))) { %>
                <div class="alert alert-warning py-2 text-center">You must log in to access that page.</div>
            <% } else if ("logged_out".equals(request.getParameter("message"))) { %>
                <div class="alert alert-success py-2 text-center">You have successfully logged out.</div>
            <% } else if ("registered".equals(request.getParameter("message"))) { %>
                <div class="alert alert-success py-2 text-center">Account created! Please log in.</div>
            <% } %>

            <!-- Login Form -->
            <form action="LoginServlet" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Username</label>
                    <input type="text" name="username" class="form-control" required placeholder="Enter your username">
                </div>
                <div class="mb-4">
                    <label class="form-label fw-semibold">Password</label>
                    <input type="password" name="password" class="form-control" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn btn-cafe w-100 py-2 fw-bold">Login</button>
            </form>

            <!-- Registration Link -->
            <div class="text-center mt-4">
                <p class="mb-0 text-muted">Don't have an account? <br>
                    <a href="register.jsp" style="color: #a87b51; font-weight: 600; text-decoration: none;">Register here</a>
                </p>
            </div>
        </div>
    </main>

    <!-- Master Footer -->
    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>