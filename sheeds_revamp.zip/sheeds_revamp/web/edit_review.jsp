<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Review | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <%@ include file="navbar.jsp" %>
    
    <div class="container py-5">
        <div class="card mx-auto shadow-sm" style="max-width: 600px;">
            <div class="card-body">
                <h4 class="fw-bold mb-4">Edit Your Review</h4>
                
                <form action="ReviewServlet" method="POST">
                    
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="reviewId" value="${param.reviewId}">
                    
                    <div class="mb-3">
                        <label class="form-label">Rating (1-5)</label>
                        <input type="number" name="rating" class="form-control" min="1" max="5" value="${param.oldRating}" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label">Comments</label>
                        <textarea name="comments" class="form-control" rows="5" required>${param.oldComments}</textarea>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <a href="ReviewServlet" class="btn btn-outline-secondary w-50">Cancel</a>
                        <button type="submit" class="btn btn-primary w-50">Save Changes</button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
    
</body>
</html>