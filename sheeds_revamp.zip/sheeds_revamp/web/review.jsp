<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Reviews | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Using the same fonts and styling from your Menu page for consistency -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Include your Navbar -->
    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1">
        
        <!-- Header Section -->
        <div class="text-center mb-5">
            <h2 class="fw-bold" style="color: #3a2b1c;">Customer Reviews</h2>
            <hr style="width: 50px; margin: auto; border: 2px solid #3a2b1c;">
        </div>

        <!-- REVIEWS GRID -->
        <div class="row">
            <c:choose>
                <c:when test="${not empty reviews}">
                    <c:forEach var="rev" items="${reviews}">
                        <div class="col-md-6 mb-4">
                            <div class="card p-4 shadow-sm h-100 border-0">
                                <h5 class="fw-bold mb-1">${rev.username}</h5>
                                <p class="text-warning fw-bold mb-3">Rating: ${rev.rating}/5</p>
                                <p class="mb-3 text-muted">${rev.comments}</p>
                                
                                <!-- ACTION BUTTONS: Only show if the logged-in user wrote this review -->
                                <c:if test="${sessionScope.user == rev.username}">
                                    <div class="mt-auto pt-3 border-top">
                                        
                                        <!-- EDIT BUTTON -->
                                        <form action="edit_review.jsp" method="POST" style="display:inline;">
                                            <input type="hidden" name="reviewId" value="${rev.reviewId}">
                                            <input type="hidden" name="oldRating" value="${rev.rating}">
                                            <input type="hidden" name="oldComments" value="${rev.comments}">
                                            <button type="submit" class="btn btn-sm btn-outline-primary">Edit</button>
                                        </form>
                                        
                                        <!-- DELETE BUTTON -->
                                        <form action="ReviewServlet" method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="reviewId" value="${rev.reviewId}">
                                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this review?');">Delete</button>
                                        </form>
                                        
                                    </div>
                                </c:if>

                            </div>
                        </div>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <div class="col-12 text-center mt-4">
                        <p class="text-muted">No reviews yet. Be the first to share your experience!</p>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>

        <hr class="my-5" style="border-color: #e2d9d0;">

        <!-- WRITE A REVIEW FORM / LOGIN PROMPT -->
        <c:choose>
            <%-- If the user IS logged in, show the form --%>
            <c:when test="${not empty sessionScope.user}">
                <div class="card mx-auto shadow-sm border-0" style="max-width: 600px;">
                    <div class="card-body p-4">
                        <h4 class="fw-bold mb-4 text-center">Write a Review</h4>
                        <form action="ReviewServlet" method="POST">
                            <input type="hidden" name="action" value="add">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Rating (1-5)</label>
                                <input type="number" name="rating" class="form-control" min="1" max="5" required>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-semibold">Comments</label>
                                <textarea name="comments" class="form-control" rows="4" required></textarea>
                            </div>
                            <button type="submit" class="btn w-100 fw-bold" style="background-color: #3a2b1c; color: white;">Post Review</button>
                        </form>
                    </div>
                </div>
            </c:when>
            
            <%-- If the user IS NOT logged in, show the prompt --%>
            <c:otherwise>
                <div class="card mx-auto shadow-sm text-center border-0" style="max-width: 600px; background-color: #f8f5f2;">
                    <div class="card-body py-5">
                        <h5 class="fw-bold mb-3" style="color: #3a2b1c;">Want to share your experience?</h5>
                        <p class="text-muted mb-4">You must be logged in to leave a customer review.</p>
                        
                        <a href="login.jsp" class="btn px-4 fw-bold" style="border: 2px solid #3a2b1c; color: #3a2b1c;">Log In</a>
                        <span class="mx-3 text-muted">or</span>
                        <a href="register.jsp" class="btn px-4 fw-bold" style="background-color: #3a2b1c; color: white;">Sign Up</a>
                    </div>
                </div>
            </c:otherwise>
        </c:choose>

    </main>

    <!-- Include your Footer -->
    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>