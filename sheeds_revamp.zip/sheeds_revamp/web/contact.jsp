<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body style="background-color: var(--cafe-cream);">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5">
        <div class="row mt-5 align-items-center">
            
            <div class="col-md-5 mb-4">
                <h2 style="font-family: 'Playfair Display', serif; color: var(--cafe-brown);" class="fw-bold mb-4">Visit Us</h2>
                <div class="mb-4">
                    <h5 class="fw-bold" style="color: var(--cafe-brown);">Address:</h5>
                    <p class="text-muted">9013, Kg Gong Pak Jin, 21300,<br>Kuala Terengganu, Terengganu, Malaysia</p>
                </div>
                <div class="mb-4">
                    <h5 class="fw-bold" style="color: var(--cafe-brown);">Hours:</h5>
                    <p class="text-muted">Mon - Sun: 6:30 AM - 11:00 PM</p>
                </div>
                <div>
                    <h5 class="fw-bold" style="color: var(--cafe-brown);">Email & Phone:</h5>
                    <p class="text-muted mb-0">Hello@Sheedscafe.com</p>
                    <p class="text-muted">+60 12-345 6789</p>
                </div>
            </div>

            <div class="col-md-7">
                
                <% if ("true".equals(request.getParameter("success"))) { %>
                    <div class="alert alert-success fw-bold text-center mb-4 shadow-sm" style="border-radius: 10px;">
                        <i class="bi bi-check-circle-fill me-2"></i> Message sent successfully! We will get back to you soon.
                    </div>
                <% } %>

                <form action="InboxServlet" method="POST" class="bg-white p-5 rounded-4 shadow-sm">
                    <h4 class="mb-4 fw-bold text-center" style="color: var(--cafe-brown);">Send us a message</h4>
                    
                    <div class="mb-4">
                        <label class="form-label fw-medium text-muted">Your Name</label>
                        <input type="text" name="name" class="form-control form-control-lg bg-light" placeholder="e.g. Ahmad Zaki" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-medium text-muted">Your Email</label>
                        <input type="email" name="email" class="form-control form-control-lg bg-light" placeholder="e.g. ahmad@example.com" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-medium text-muted">Your Message</label>
                        <textarea name="message" class="form-control form-control-lg bg-light" rows="4" placeholder="How can we help you today?" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill shadow-sm" style="background-color: var(--cafe-brown); border: none;">
                        Send Message <i class="bi bi-send ms-1"></i>
                    </button>
                </form>
            </div>

        </div>
    </main>

    <footer class="footer mt-5" style="background-color: #2f1f14;">
        <div class="container text-center text