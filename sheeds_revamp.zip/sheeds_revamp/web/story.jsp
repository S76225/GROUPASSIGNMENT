<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Story | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1">
        <div class="row align-items-center mt-5">
            <div class="col-md-6 mb-4 mb-md-0">
                <img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=800&q=80" alt="Sheed's Cafe Story" class="img-fluid rounded shadow-sm">
            </div>
            <div class="col-md-6 ps-md-5">
                <h2 class="mb-4 fw-bold" style="color: #3a2b1c;">Our Story</h2>
                <p>Sheed's Cafe began as a small coffee stall located near a university campus, serving simple, high-quality coffee to students and early risers.</p>
                <p>As demand increased, Sheed's Cafe took a step forward by transforming from a small stall into a warm, welcoming brick-and-mortar cafe space.</p>
                <p>Today, Sheed's Cafe stands as a modern café that continues to serve quality beverages and light pastries to our beloved community.</p>
            </div>
        </div>
    </main>

    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>