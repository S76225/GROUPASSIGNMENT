<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%
    // Verify admin status
    if (session.getAttribute("user") == null || !"admin".equals(session.getAttribute("role"))) {
        response.sendRedirect("login.jsp?error=unauthorized");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Manage Reviews | Admin Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background-color: #fbf8cc;
                display: flex;
                height: 100vh;
                overflow: hidden;
            }
            .main-content {
                flex: 1;
                padding: 30px;
                overflow-y: auto;
            }
            .card {
                border-radius: 15px;
                border: none;
                box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            }
        </style>
    </head>
    <body>

        <!-- Shared Admin Sidebar -->
        <%@ include file="admin_sidebar.jsp" %>

        <div class="main-content">
            <h2 class="mb-4 fw-bold">Manage Customer Reviews</h2>

            <div class="card shadow-sm">
                <div class="card-body">
                    <table class="table table-hover mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Review ID</th>
                                <th>Customer Name</th>
                                <th>Rating</th>
                                <th>Comments</th>
                                <th>Action</th> </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="rev" items="${reviews}">
                                <tr>
                                    <td>#${rev.reviewId}</td>
                                    <td>${rev.username}</td>
                                    <td><span class="badge bg-warning text-dark"><i class="bi bi-star-fill"></i> ${rev.rating}</span></td>
                                    <td>${rev.comments}</td>
                                    <td>
                                        <form action="ReviewServlet" method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="reviewId" value="${rev.reviewId}">

                                            <input type="hidden" name="source" value="admin">

                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to permanently delete this review?');">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>