<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Orders | Admin Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background-color: #fbf8cc; 
            display: flex; 
            height: 100vh; 
            overflow: hidden; 
        }
        .main-content { 
            flex: 1; 
            padding: 30px; 
            overflow-y: auto; 
        }
        .content-card { 
            background-color: white; 
            border-radius: 15px; 
            padding: 30px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.05); 
        }
        .badge-prep { 
            background-color: #fcebd5; 
            color: #d35400; 
            padding: 5px 15px; 
            border-radius: 20px; 
            font-size: 0.85rem; 
        }
        .badge-ready { 
            background-color: #d9ead3; 
            color: #38761d; 
            padding: 5px 15px; 
            border-radius: 20px; 
            font-size: 0.85rem; 
        }
    </style>
</head>
<body>

    <%@ include file="admin_sidebar.jsp" %>

    <div class="main-content">
        <h3 class="mb-4 fw-bold">Recent Orders</h3>
        <div class="content-card">
            <table class="table table-borderless">
                <thead class="text-muted border-bottom">
                    <tr>
                        <th>ORDER ID</th>
                        <th>CUSTOMER</th>
                        <th>TYPE</th>
                        <th>TOTAL</th>
                        <th>STATUS</th>
                        <th>ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="order" items="${ordersList}">
                        <tr>
                            <td class="fw-bold">${order.orderId}</td>
                            <td>${order.customerName}</td>
                            <td>${order.orderType}</td>
                            <td>RM ${order.totalAmount}</td>
                            <td>
                                <c:choose>
                                    <c:when test="${order.status == 'Ready'}">
                                        <span class="badge-ready">Ready</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge-prep">${order.status}</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <a href="OrderServlet?action=markReady&id=${order.orderId}" class="btn btn-sm btn-light">
                                    <i class="bi bi-check-circle"></i>
                                </a>
                                <a href="OrderServlet?action=delete&id=${order.orderId}" class="btn btn-sm btn-light">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>