<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<footer class="footer mt-5" style="background-color: #2f1f14;">
    <div class="container text-center text-md-start pt-4 pb-2">
        <div class="row">
            <!-- Brand Column -->
            <div class="col-md-4 mb-3">
                <h5 class="footer-title text-white">Sheed's Cafe</h5>
                <p class="footer-tagline text-white-50">Where Every Cup Tells a Story</p>
            </div>
            
            <!-- Contact Column -->
            <div class="col-md-4 mb-3">
                <h6 class="text-white fw-bold">Contact Us</h6>
                <p style="line-height: 2;">
                    <i class="bi bi-geo-alt-fill text-white-50 me-2"></i><a href="https://maps.google.com/?q=9013,+Kg+Gong+Pak+Jin,+21300,+Kuala+Terengganu" class="text-white-50 text-decoration-none">9013, Kg Gong Pak Jin, 21300, Kuala Terengganu</a><br>
                    <i class="bi bi-envelope-fill text-white-50 me-2"></i><a href="mailto:hello@sheedscafe.com" class="text-white-50 text-decoration-none">hello@sheedscafe.com</a><br>
                    <i class="bi bi-telephone-fill text-white-50 me-2"></i><a href="tel:+60123456789" class="text-white-50 text-decoration-none">+60 12-345 6789</a>
                </p>
            </div>

            <!-- Social Media Column -->
            <div class="col-md-4 mb-3">
                <h6 class="text-white fw-bold">Follow Us</h6>
                <div class="d-flex gap-3 justify-content-center justify-content-md-start mt-2">
                    <a href="#" class="text-white-50 fs-5"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-white-50 fs-5"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="text-white-50 fs-5"><i class="bi bi-twitter-x"></i></a>
                </div>
            </div>
        </div>

        <hr class="border-secondary my-3">

        <!-- Copyright (Centered) -->
        <div class="d-flex flex-column flex-md-row justify-content-center align-items-center">
            <p class="mb-0 text-white-50 small">&copy; 2026 Sheed's Cafe. All rights reserved.</p>
        </div>
    </div>
</footer>