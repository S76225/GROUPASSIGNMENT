<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1">
        <div class="text-center mb-5">
            <h2 class="fw-bold" style="color: #3a2b1c;">Our Selection</h2>
            <hr style="width: 50px; margin: auto; border: 2px solid #3a2b1c;">
        </div>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <!-- Updated to match the attribute name set in MenuServlet -->
            <c:forEach var="item" items="${menuList}">
                <div class="col">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold">${item.name}</h5>
                            <!-- Changed to item.category to match the MenuItem model -->
                            <p class="card-text text-muted">${item.category}</p>
                            <h6 class="text-success fw-bold">RM ${item.price}</h6>
                        </div>
                    </div>
                </div>
            </c:forEach>
            
            <!-- Updated to match the attribute name set in MenuServlet -->
            <c:if test="${empty menuList}">
                <div class="col-12 text-center text-muted">
                    <p>Our menu is currently being updated. Check back soon!</p>
                </div>
            </c:if>
        </div>
    </main>

    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>