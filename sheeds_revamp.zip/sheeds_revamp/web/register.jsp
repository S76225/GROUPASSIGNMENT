<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Account | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
        .auth-card { background-color: white; border-radius: 12px; border: none; }
        .btn-cafe { background-color: #4a3b32; color: white; transition: 0.3s; }
        .btn-cafe:hover { background-color: #2b1f17; color: white; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1 d-flex justify-content-center align-items-center">
        <div class="card auth-card shadow-sm p-4" style="max-width: 450px; width: 100%;">
            <div class="text-center mb-4">
                <h3 class="fw-bold" style="color: #3a2b1c;">Join Sheed's Cafe</h3>
                <p class="text-muted">Create an account to order online and leave reviews.</p>
            </div>

            <!-- Error Message Display -->
            <% if (request.getParameter("error") != null) { %>
                <div class="alert alert-danger py-2">Username already exists. Please choose another.</div>
            <% } %>

            <form action="RegisterServlet" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Username</label>
                    <input type="text" name="username" class="form-control" required placeholder="e.g. ahmad_faiz">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email Address</label>
                    <input type="email" name="email" class="form-control" required placeholder="ahmad@example.com">
                </div>
                <div class="mb-4">
                    <label class="form-label fw-semibold">Password</label>
                    <input type="password" name="password" class="form-control" required placeholder="Create a strong password">
                </div>
                <button type="submit" class="btn btn-cafe w-100 py-2 fw-bold">Create Account</button>
            </form>

            <div class="text-center mt-4">
                <p class="mb-0 text-muted">Already have an account? <a href="login.jsp" style="color: #a87b51; font-weight: 600;">Log in here</a></p>
            </div>
        </div>
    </main>

    <%@ include file="footer.jsp" %>

</body>
</html>