<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sheed's Cafe | Where Every Cup Tells a Story</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
        .hero-section { background-color: #f5eedc; padding: 120px 0; text-align: center; }
        .hero-title { font-weight: 700; font-size: 3.5rem; color: #3a2b1c; }
        .btn-cafe-primary { background-color: #4a3b32; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: 0.3s; }
        .btn-cafe-primary:hover { background-color: #2b1f17; color: white; }
        .btn-cafe-outline { border: 2px solid #4a3b32; color: #4a3b32; padding: 10px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: 0.3s; }
        .btn-cafe-outline:hover { background-color: #4a3b32; color: white; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="flex-grow-1">
        <header class="hero-section">
            <div class="container">
                <h1 class="hero-title mb-4">Where Every Cup Tells a Story</h1>
                <p class="lead mb-5" style="max-width: 600px; margin: 0 auto;">
                    Skip the line and order your favorite brew ahead of time. Experience the finest coffee and freshest pastries in Terengganu.
                </p>
                <div class="d-flex justify-content-center gap-3">
                    <a href="OrderServlet" class="btn-cafe-primary shadow-sm">Order Online</a>
                    <a href="MenuServlet" class="btn-cafe-outline">View Menu</a>
                </div>
            </div>
        </header>
    </main>

    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>