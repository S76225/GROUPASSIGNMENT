<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Drip | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdfaf6; color: #4a3b32; }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1">
        <h2 class="section-title mt-5 mb-4 fw-bold" style="color: #3a2b1c;">The Drip</h2>
        
        <div class="row">
            <div class="col-md-8 mx-auto">
                <article class="card mb-4 overflow-hidden shadow-sm border-0">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=800&q=80" alt="Home Brewing" class="img-fluid h-100 object-fit-cover">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h3 class="fw-bold">5 Tips for Better Home Brewing</h3>
                                <p>Master simple brewing techniques to improve the taste of your coffee at home...</p>
                                <a href="#" style="color: #a87b51; font-weight: bold; text-decoration: none;">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </article>

                <article class="card mb-4 overflow-hidden shadow-sm border-0">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80" alt="Cafe Culture" class="img-fluid h-100 object-fit-cover">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h3 class="fw-bold">Café Culture: More Than Just Coffee</h3>
                                <p>A look into how cafés have become spaces for studying, working, and connecting...</p>
                                <a href="#" style="color: #a87b51; font-weight: bold; text-decoration: none;">Read More <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </main>

    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>