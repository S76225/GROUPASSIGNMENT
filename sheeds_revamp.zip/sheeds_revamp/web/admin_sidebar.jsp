<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<style>
    /* Sidebar Container */
    .admin-sidebar {
        width: 260px;
        background-color: #3a2b1c; /* Matches your cafe's dark brown theme */
        color: white;
        height: 100vh;
        padding: 40px 20px;
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
    }
    
    .admin-sidebar .brand-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: white;
        text-decoration: none;
        margin-bottom: 40px;
        padding-left: 10px;
    }
    
    .admin-sidebar .nav-link {
        color: #eaddd7; 
        font-size: 1.1rem;
        padding: 12px 15px;
        border-radius: 10px;
        transition: 0.3s;
        display: flex;
        align-items: center;
        text-decoration: none;
    }
    
    .admin-sidebar .nav-link i {
        margin-right: 12px;
        font-size: 1.2rem;
    }
    
    .admin-sidebar .nav-link:hover {
        background-color: rgba(255, 255, 255, 0.05);
        color: white;
    }
    
    /* The Highlight Box */
    .admin-sidebar .active-link {
        background-color: #5c4738; 
        color: white;
        font-weight: 500;
    }
</style>

<div class="admin-sidebar">
    
    <div class="brand-title">Sheed's Café</div>

    <div class="d-flex flex-column gap-2">
        <a href="MenuServlet?view=admin" class="nav-link">
            <i class="bi bi-cup-hot"></i> Menu
        </a>
        
        <a href="OrderServlet?view=admin" class="nav-link">
            <i class="bi bi-receipt"></i> Orders
        </a>
        
        <a href="ReviewServlet?view=admin" class="nav-link">
            <i class="bi bi-star"></i> Reviews
        </a>
        
        <a href="InboxServlet?view=admin" class="nav-link">
            <i class="bi bi-envelope"></i> Inbox
        </a>
    </div>

    <div class="mt-auto d-flex flex-column gap-2">
        <hr class="text-white opacity-25">
        <a href="LogoutServlet" class="nav-link" style="color: #ff8b8b;">
            <i class="bi bi-box-arrow-left"></i> Logout
        </a>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // 1. Get the current URL from the browser (e.g., ".../OrderServlet?view=admin")
        let currentUrl = window.location.href;

        // 2. Grab every link inside the sidebar
        let navLinks = document.querySelectorAll('.admin-sidebar .nav-link');

        // 3. Loop through the links and check if they match the URL
        navLinks.forEach(link => {
            // Ignore the logout button
            if (!link.href.includes("Logout")) {
                // If the link's destination is found inside the current browser URL, highlight it!
                if (currentUrl.includes(link.getAttribute('href'))) {
                    link.classList.add('active-link');
                }
            }
        });
    });
</script>