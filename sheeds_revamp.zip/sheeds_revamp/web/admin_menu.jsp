<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu | Admin Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fbf8cc; display: flex; height: 100vh; overflow: hidden; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .content-card { background-color: white; border-radius: 15px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .badge-active { background-color: #d9ead3; color: #38761d; padding: 5px 15px; border-radius: 20px; font-size: 0.85rem; }
    </style>
</head>
<body>

    <%@ include file="admin_sidebar.jsp" %>

    <div class="main-content">
        <div class="d-flex justify-content-between mb-4">
            <h3 class="fw-bold">Menu Management</h3>
            <button type="button" class="btn" style="background-color: #3a2b1c; color: white;" data-bs-toggle="modal" data-bs-target="#addMenuModal">+ Add Item</button>
        </div>

        <div class="content-card">
            <table class="table table-borderless">
                <thead class="text-muted border-bottom">
                    <tr><th>ITEM ID</th><th>NAME</th><th>CATEGORY</th><th>PRICE</th><th>STATUS</th><th>ACTIONS</th></tr>
                </thead>
                <tbody>
                    <c:forEach var="item" items="${menuList}">
                        <tr>
                            <td class="fw-bold">${item.itemId}</td>
                            <td>${item.name}</td>
                            <td>${item.category}</td>
                            <td>RM ${item.price}</td>
                            <td><span class="badge-active">${item.status}</span></td>
                            <td><a href="MenuServlet?action=delete&id=${item.itemId}" class="btn btn-sm btn-light"><i class="bi bi-trash"></i></a></td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="addMenuModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color: #fbf8cc;">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold">Add New Menu Item</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="MenuServlet" method="POST">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3"><label class="form-label">Item Name</label><input type="text" name="name" class="form-control" required></div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category" class="form-select">
                                <option value="Espresso">Espresso</option><option value="Cold Drinks">Cold Drinks</option>
                                <option value="Non-Coffee">Non-Coffee</option><option value="Pastry">Pastry</option>
                            </select>
                        </div>
                        <div class="mb-3"><label class="form-label">Price (RM)</label><input type="number" step="0.01" name="price" class="form-control" required></div>
                        <button type="submit" class="btn w-100 py-2 text-white" style="background-color: #3a2b1c;">Save Item</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>