<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Online | Sheed's Cafe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background-color: #fdfaf6; 
            color: #4a3b32; 
        }
        .order-card {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }
        .btn-cafe {
            background-color: #4a3b32;
            color: white;
            transition: 0.3s;
        }
        .btn-cafe:hover {
            background-color: #352a23;
            color: white;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

    <%@ include file="navbar.jsp" %>

    <main class="container py-5 flex-grow-1 d-flex justify-content-center align-items-center">
        
        <div class="order-card p-5 w-100" style="max-width: 650px;">
            
            <div class="text-center mb-5">
                <h2 class="fw-bold mb-2" style="color: #4a3b32;">Express Order</h2>
                <p class="text-muted">Skip the line and order your favorite brew ahead of time.</p>
            </div>

            <form action="OrderServlet" method="POST">
                <input type="hidden" name="action" value="placeOrder">

                <div class="mb-4">
                    <label class="form-label fw-semibold">Your Name</label>
                    <input type="text" name="customerName" class="form-control form-control-lg bg-light border-0" 
                           placeholder="e.g. Ahmad Faiz" 
                           value="${not empty sessionScope.user ? sessionScope.user : ''}" required>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Select Your Brew / Item</label>
                    <select name="itemName" class="form-select form-select-lg bg-light border-0" required>
                        <option value="" disabled selected>Choose a drink or pastry...</option>
                        <c:forEach var="item" items="${menuList}">
                            <c:if test="${item.status == 'Available'}">
                                <option value="${item.name}">
                                    ${item.name} - RM ${item.price}
                                </option>
                            </c:if>
                        </c:forEach>
                    </select>
                </div>

                <div class="row mb-5">
                    <div class="col-md-6 mb-4 mb-md-0">
                        <label class="form-label fw-semibold">Quantity</label>
                        <input type="number" name="quantity" class="form-control form-control-lg bg-light border-0" 
                               min="1" max="20" value="1" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Order Type</label>
                        <select name="orderType" class="form-select form-select-lg bg-light border-0" required>
                            <option value="Pickup">Pickup</option>
                            <option value="Dine-in">Dine-in</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-cafe btn-lg w-100 fw-bold">Place Order</button>
            </form>
        </div>

    </main>

    <%@ include file="footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <c:if test="${param.success == 'true'}">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                Swal.fire({
                    title: 'Order Placed!',
                    text: 'Your order has been sent directly to the kitchen.',
                    icon: 'success',
                    confirmButtonText: 'Awesome',
                    confirmButtonColor: '#4a3b32'
                }).then(() => {
                    window.history.replaceState(null, null, window.location.pathname);
                });
            });
        </script>
    </c:if>
    
</body>
</html>